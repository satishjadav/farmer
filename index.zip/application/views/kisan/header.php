<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/css/bootstrap/css/bootstrap.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/icon/icofont/css/icofont.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/css/jquery.mCustomScrollbar.css">


  <!-- Google font-->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/css/bootstrap/css/bootstrap.min.css">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/icon/themify-icons/themify-icons.css">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/icon/icofont/css/icofont.css">
     <!-- Notification.css -->
     <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/pages/notification/notification.css">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/kisan/css/jquery.mCustomScrollbar.css">
    <link href="<?php echo base_url(); ?>application/views/kisan/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
  


<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/popper.js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/bootstrap/js/bootstrap.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/modernizr/modernizr.js"></script>
<!-- am chart -->
<script src="<?php echo base_url(); ?>application/views/kisan/pages/widget/amchart/amcharts.min.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/pages/widget/amchart/serial.min.js"></script>
<!-- Todo js -->
<script type="text/javascript " src="<?php echo base_url(); ?>application/views/kisan/pages/todo/todo.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/pages/dashboard/custom-dashboard.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/script.js"></script>
<script type="text/javascript " src="<?php echo base_url(); ?>application/views/kisan/js/SmoothScroll.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/pcoded.min.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/demo-12.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/jquery.mCustomScrollbar.concat.min.js"></script>



<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <!-- Required Jquery -->
    <script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/popper.js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/bootstrap/bootstrap.bundle.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/jquery-slimscroll/jquery.slimscroll.js"></script>
<!-- modernizr js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/modernizr/modernizr.js"></script>
<!-- notification js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/bootstrap-growl.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/pages/notification/notification.js"></script>
<!-- am chart -->
<script src="<?php echo base_url(); ?>application/views/kisan/pages/widget/amchart/amcharts.min.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/pages/widget/amchart/serial.min.js"></script>
<!-- Todo js -->
<script type="text/javascript " src="<?php echo base_url(); ?>application/views/kisan/pages/todo/todo.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/pages/dashboard/custom-dashboard.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/views/kisan/js/script.js"></script>
<script type="text/javascript " src="<?php echo base_url(); ?>application/views/kisan/js/SmoothScroll.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/pcoded.min.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/demo-12.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- <script src="<?php //echo base_url(); ?>application/views/kisan/js/dataTables.bootstrap4.min.js"></script> -->
<script src="<?php echo base_url(); ?>application/views/kisan/js/datatables-demo.js"></script>
<script src="<?php echo base_url(); ?>application/views/kisan/js/jquery.dataTables.min.js"></script>